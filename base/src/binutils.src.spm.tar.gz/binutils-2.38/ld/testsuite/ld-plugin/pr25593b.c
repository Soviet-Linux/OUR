extern void xyz ();

void
xxx (void)
{
  xyz ();
}
