int global_var = 20;
