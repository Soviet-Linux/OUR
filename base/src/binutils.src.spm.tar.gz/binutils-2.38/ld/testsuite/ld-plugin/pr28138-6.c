extern int a5(void);
int
a6(void)
{
  return 1 + a5();
}
