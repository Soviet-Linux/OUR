void
x6 (void)
{
}
