extern int xxx;

int
bar (void)
{
  return xxx;
}

int
main ()
{
  return 0;
}
