.*warning: no input section rule matches .lower.text in linker script
