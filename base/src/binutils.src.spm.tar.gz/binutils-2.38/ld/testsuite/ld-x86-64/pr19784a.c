void bar(void);
int main(void)
{
  bar();
  return 0;
}
