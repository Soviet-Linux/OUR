#include <stdio.h>

void
test()
{
  printf ("PASS\n");
}
