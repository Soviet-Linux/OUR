int copy = 1;

int
get_copy ()
{
  return copy;
}

int *
get_copy_p ()
{
  return &copy;
}
