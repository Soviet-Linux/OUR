char bar[10];
