int foo = 0;
