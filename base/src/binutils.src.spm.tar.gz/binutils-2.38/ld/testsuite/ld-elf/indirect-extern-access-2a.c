void
indirect_extern_access (void)
{
}

void *
indirect_extern_access_p (void)
{
  return indirect_extern_access;
}
