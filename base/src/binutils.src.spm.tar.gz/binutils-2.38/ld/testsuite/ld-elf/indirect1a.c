extern void bar (void);

int
start (void)
{
  bar ();
  return 0;
}
