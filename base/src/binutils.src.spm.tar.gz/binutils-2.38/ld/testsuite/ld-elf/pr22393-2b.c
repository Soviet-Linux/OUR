void test(void);

int main()
{
  test();
  return 0;
}
