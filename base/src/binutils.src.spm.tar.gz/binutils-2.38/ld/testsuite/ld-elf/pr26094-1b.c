extern void *foo();

int main (void)
{
  foo(); return 0;
}
