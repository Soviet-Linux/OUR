source_sh ${srcdir}/emulparams/shlelf_fd.sh
OUTPUT_FORMAT="elf32-shbig-fdpic"
