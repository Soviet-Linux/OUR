source_sh ${srcdir}/emulparams/armelf_linux_fdpiceabi.sh
OUTPUT_FORMAT="elf32-bigarm-fdpic"
