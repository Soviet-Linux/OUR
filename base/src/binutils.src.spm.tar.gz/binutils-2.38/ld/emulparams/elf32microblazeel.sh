source_sh ${srcdir}/emulparams/elf32microblaze.sh
OUTPUT_FORMAT=$LITTLE_OUTPUT_FORMAT
