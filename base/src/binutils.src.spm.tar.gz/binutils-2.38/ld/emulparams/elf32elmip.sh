EMBEDDED=yes
source_sh ${srcdir}/emulparams/elf32lmip.sh
