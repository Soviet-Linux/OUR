source_sh ${srcdir}/emulparams/elf64lriscv_lp64f.sh
OUTPUT_FORMAT="elf64-bigriscv"
