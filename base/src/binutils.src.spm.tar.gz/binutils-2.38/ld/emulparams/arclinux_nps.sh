source_sh ${srcdir}/emulparams/arclinux.sh
# Extend the OTHER_SECTIONS for nps.
source_sh ${srcdir}/emulparams/arc-nps.sh
