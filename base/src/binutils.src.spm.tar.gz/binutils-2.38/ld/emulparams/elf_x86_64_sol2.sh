source_sh ${srcdir}/emulparams/elf_x86_64.sh
source_sh ${srcdir}/emulparams/solaris2.sh
EXTRA_EM_FILE="solaris2-x86"
OUTPUT_FORMAT="elf64-x86-64-sol2"
