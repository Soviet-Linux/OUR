source_sh ${srcdir}/emulparams/elf32lmip.sh
ENTRY=__start
