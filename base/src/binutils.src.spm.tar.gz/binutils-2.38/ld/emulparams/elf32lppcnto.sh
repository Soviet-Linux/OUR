source_sh ${srcdir}/emulparams/elf32ppc.sh
OUTPUT_FORMAT="elf32-powerpcle"
MAXPAGESIZE="CONSTANT (MAXPAGESIZE)"
TEXT_START_ADDR=0x48040000

