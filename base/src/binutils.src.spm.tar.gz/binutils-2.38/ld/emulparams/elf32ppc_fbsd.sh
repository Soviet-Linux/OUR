source_sh ${srcdir}/emulparams/elf32ppc.sh
source_sh ${srcdir}/emulparams/elf_fbsd.sh

OUTPUT_FORMAT="elf32-powerpc-freebsd"

