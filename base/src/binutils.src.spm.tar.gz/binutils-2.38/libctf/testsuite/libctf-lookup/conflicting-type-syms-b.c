typedef long a_t;
typedef long b_t;

a_t b;
b_t ignore1;
