/* Dummy header to avoid modifying pty.c */
#include "os.h"
