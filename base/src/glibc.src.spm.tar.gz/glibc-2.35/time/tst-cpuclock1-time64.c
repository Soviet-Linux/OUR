#include "tst-cpuclock1.c"
