#include "tst-timespec_get.c"
