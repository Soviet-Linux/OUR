#include "tst-clock2.c"
