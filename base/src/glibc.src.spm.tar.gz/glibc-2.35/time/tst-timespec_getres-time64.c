#include "tst-timespec_getres.c"
