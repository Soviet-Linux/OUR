#define WIDE 1
#include "../string/test-strchr.c"
