#include "tst-quad2.c"
