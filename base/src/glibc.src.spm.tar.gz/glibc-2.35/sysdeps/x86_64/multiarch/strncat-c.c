#define STRNCAT __strncat_sse2
#include <string/strncat.c>
