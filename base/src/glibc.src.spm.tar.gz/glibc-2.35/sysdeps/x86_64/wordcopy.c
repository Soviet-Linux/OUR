/* X86-64 doesn't use memory copy functions.  */
