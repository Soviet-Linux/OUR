#include <sysdeps/i386/nptl/pthread_spin_init.c>
