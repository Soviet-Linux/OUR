#include "test-float-libmvec-tanf.c"
