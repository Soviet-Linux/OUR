#define LIBMVEC_TYPE float
#define LIBMVEC_FUNC log2f
#include "test-vector-abi-arg1.h"
