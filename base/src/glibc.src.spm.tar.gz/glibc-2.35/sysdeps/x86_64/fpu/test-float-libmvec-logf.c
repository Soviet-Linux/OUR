#define LIBMVEC_TYPE float
#define LIBMVEC_FUNC logf
#include "test-vector-abi-arg1.h"
