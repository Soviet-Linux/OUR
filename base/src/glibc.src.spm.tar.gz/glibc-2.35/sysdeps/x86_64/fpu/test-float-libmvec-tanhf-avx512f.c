#include "test-float-libmvec-tanhf.c"
