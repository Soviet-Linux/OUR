#define LIBMVEC_TYPE float
#define LIBMVEC_FUNC tanhf
#include "test-vector-abi-arg1.h"
