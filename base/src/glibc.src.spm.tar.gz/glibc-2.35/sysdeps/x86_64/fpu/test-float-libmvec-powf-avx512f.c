#include "test-float-libmvec-powf.c"
