#define REQUIRE_AVX
#include "test-vector-abi.h"
