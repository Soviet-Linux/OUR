#define REQUIRE_AVX2
#include "test-vector-abi.h"
