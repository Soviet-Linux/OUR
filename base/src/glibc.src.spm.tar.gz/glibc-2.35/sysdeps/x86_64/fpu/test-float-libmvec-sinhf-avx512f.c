#include "test-float-libmvec-sinhf.c"
