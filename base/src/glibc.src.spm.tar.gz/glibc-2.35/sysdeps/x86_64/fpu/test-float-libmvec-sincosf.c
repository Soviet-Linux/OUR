#define LIBMVEC_TYPE float
#define LIBMVEC_SINCOS sincosf
#include "test-vector-abi-sincos.h"
