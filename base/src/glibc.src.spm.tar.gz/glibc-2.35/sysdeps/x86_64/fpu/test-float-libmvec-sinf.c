#define LIBMVEC_TYPE float
#define LIBMVEC_FUNC sinf
#include "test-vector-abi-arg1.h"
