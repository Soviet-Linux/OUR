#include "test-float-libmvec-sincosf.c"
