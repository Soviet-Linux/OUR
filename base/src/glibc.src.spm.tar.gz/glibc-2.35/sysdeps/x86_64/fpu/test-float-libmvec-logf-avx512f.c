#include "test-float-libmvec-logf.c"
