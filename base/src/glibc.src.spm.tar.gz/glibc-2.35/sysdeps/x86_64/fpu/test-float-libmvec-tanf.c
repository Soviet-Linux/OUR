#define LIBMVEC_TYPE float
#define LIBMVEC_FUNC tanf
#include "test-vector-abi-arg1.h"
