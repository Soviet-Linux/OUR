#define LIBMVEC_TYPE float
#define LIBMVEC_FUNC sinhf
#include "test-vector-abi-arg1.h"
