#define LIBMVEC_TYPE float
#define LIBMVEC_FUNC powf
#include "test-vector-abi-arg2.h"
