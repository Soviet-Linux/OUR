#include "test-float-libmvec-sinf.c"
