#include "test-float-libmvec-log2f.c"
