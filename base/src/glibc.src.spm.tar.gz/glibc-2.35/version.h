/* This file just defines the current version number of libc.  */

#define RELEASE "stable"
#define VERSION "2.35"
