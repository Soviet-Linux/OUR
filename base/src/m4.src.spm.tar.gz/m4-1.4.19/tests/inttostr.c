#define anytostr inttostr
#define inttype int
#include "anytostr.c"
