/*
 * Header file for xpm_w32.c
 */

#ifndef XPM_W32__H
int LoadXpmImage(char *filename, HBITMAP *hImage, HBITMAP *hShape);
#endif
