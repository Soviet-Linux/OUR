#define HAVE_GETOPT_LONG 1
#include "getopt_.h"
