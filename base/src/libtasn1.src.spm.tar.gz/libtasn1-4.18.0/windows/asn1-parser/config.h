#define HAVE_GETOPT_H 1
