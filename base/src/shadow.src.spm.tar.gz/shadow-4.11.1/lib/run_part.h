int run_part (char *script_path, char *name, char *action);
int run_parts (char *directory, char *name, char *action);
