extern const char *shadow_progname; /* Program name showed in error messages */
extern FILE *shadow_logfd;  /* file descripter to which error messages are printed */
