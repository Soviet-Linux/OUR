mkdir p11-build &&
cd    p11-build &&

echo "BUILD_ROOT is $1"

meson --prefix=$1/usr       \
      --buildtype=release \
      -Dtrust_paths=/etc/pki/anchors &&
ninja
