#!/bin/sh

# ##help
# #foo.sh help message
# ##end

exit 0
